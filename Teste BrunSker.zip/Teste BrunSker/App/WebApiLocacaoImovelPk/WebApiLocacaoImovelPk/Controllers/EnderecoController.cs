﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Runtime.CompilerServices;
using WebApiLocacaoImovelPk.Data;
using WebApiLocacaoImovelPk.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApiLocacaoImovelPk.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnderecoController : ControllerBase
    {
        private readonly Contexto _ctx;
        public EnderecoController(Contexto contexto)
        {
            _ctx = contexto;
        }

        // GET: api/<EstadoController>
        [HttpGet]
        public async Task<IEnumerable<Endereco>> ListaEnderecos() 
            => await _ctx.Endereco.ToListAsync();

        // GET api/<EstadoController>/5
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(Endereco), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> BuscaEndereco(int id)
        {
            var endereco = await _ctx.Endereco.FindAsync(id);
            return endereco == null ? NotFound() : Ok(endereco);
        }

        // POST api/<EstadoController>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> InsereEndereco(Endereco ender)
        {
            await _ctx.Endereco.AddAsync(ender);
            await _ctx.SaveChangesAsync();
            return CreatedAtAction(nameof(BuscaEndereco), new { id = ender.Id });
        }

        // PUT api/<EstadoController>/5
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> AlteraEndereco(int id, Endereco ender)
        {
            if (id != ender.Id) return BadRequest();
            
            _ctx.Entry(ender).State = EntityState.Modified;
            await _ctx.SaveChangesAsync();

            return NoContent();
        }

        // DELETE api/<EstadoController>/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var _enderec = await _ctx.Endereco.FindAsync(id);
            if (_enderec == null) return NotFound();

            _ctx.Endereco.Remove(_enderec);
            await _ctx.SaveChangesAsync();

            return NoContent();
        }
    }
}
