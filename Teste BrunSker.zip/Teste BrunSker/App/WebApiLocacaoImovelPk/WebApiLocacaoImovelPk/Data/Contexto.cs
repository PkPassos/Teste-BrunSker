﻿using Microsoft.EntityFrameworkCore;
using WebApiLocacaoImovelPk.Models;

namespace WebApiLocacaoImovelPk.Data
{
    public class Contexto : DbContext
    {
        public Contexto(DbContextOptions<Contexto> options)
            : base(options) => Database.EnsureCreated();

        public DbSet<Endereco> Endereco { get; set; }
    }
}
