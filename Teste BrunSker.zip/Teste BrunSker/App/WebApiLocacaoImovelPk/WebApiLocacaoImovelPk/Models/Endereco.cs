﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApiLocacaoImovelPk.Models
{
    [Table("Endereco")]
    public class Endereco
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [Display(Name = "Logradouro")]
        [StringLength(100, MinimumLength = 4, ErrorMessage = "Informe o Logradouro com o mínimo de 4 caracteres")]
        public string? Logradouro { get; set; }

        [Required]
        [Display(Name = "CEP")]
        [StringLength(10, MinimumLength = 8, ErrorMessage = "Informe o CEP com o mínimo de 8 caracteres")]
        public string? CEP { get; set; }

        [Required]
        [Display(Name = "Municipio")]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "Informe o Município com o mínimo de 3 caracteres")]
        public string? Municipio { get; set; }

        [Required]
        [Display(Name = "Estado")]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "Informe o Estado com o mínimo de 3 caracteres")]
        public string? Estado { get; set; }

        [Required]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "Informe o País com o mínimo de 3 caracteres")]
        [Display(Name = "Pais")]
        public string? Pais { get; set; }
    }
}