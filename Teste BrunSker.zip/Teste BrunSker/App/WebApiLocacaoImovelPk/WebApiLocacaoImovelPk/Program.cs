﻿using Microsoft.EntityFrameworkCore;
using WebApiLocacaoImovelPk.Data;
using WebApiLocacaoImovelPk.Models;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddControllers();

builder.Services.AddDbContext<Contexto>(options => options.UseMySql(builder.Configuration.GetConnectionString("MySQL"),
    Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.32-mysql")));

var app = builder.Build();
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.Run();